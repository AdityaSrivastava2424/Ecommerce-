export const serverUrl = import.meta.env.VITE_BACKEND_URL;
