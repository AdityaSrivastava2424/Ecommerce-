import logo from "./orebiLogo.png";
import logoLight from "./logoLight.png";

export { logo, logoLight };
