import React from "react";

const MobileNavigation = () => {
  return <div>MobileNavigation</div>;
};

export default MobileNavigation;
